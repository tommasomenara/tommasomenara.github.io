% Simulate quarter-car suspension model.

%%%%%%%%%%%%%%%%%%%%%%%%
%   Tommaso Menara     %
%      UCR-ME121       %
%%%%%%%%%%%%%%%%%%%%%%%%

clear all
close all
clc

% Initialize parameters:
k1 = 16e3; % spring stiffness [N/m]
k2 = 16e4; % tire stiffness [N/m]
c1 = 1e3; % 
m = 45; % unsprung mass [kg]
M = 250; % sprung mass [kg]
g = 9.81; % gravity acceleration
W = M*g; % weight
F = 0.01*W; % active suspension force

dt = 0.005; % time step
                        
%% Linear state space model 

% system matrix
A = [0 1 0 0; 
    -k1/M -c1/M k1/M c1/M;
    0 0 0 1;
    k1/m c1/m -(k1+k2)/m -c1/m];

% input matrix
B = [0 F/m 0 -F/m;
    0 0 0 1e-2*k2/m]';

% output matrix
C = [1 0 0 0];

% feedforward matrix
D = [0 0];

qcar_model = ss(A,B,C,D);
qcar_tf = tf(qcar_model) % transfer function of the system
zpk(qcar_tf) % zero-pole-gain model

qcar_input1 = ss(A,B(:,1),C,D(:,1));
qcar_input1_tf = tf(qcar_input1);
qcar_input2 = ss(A,B(:,2),C,D(:,2));
qcar_input2_tf = tf(qcar_input2);

%%
figure
impulse(qcar_model)

%%
figure
step(qcar_model)

%% analysis of rise time, settling time, overshoot,...
S = stepinfo(qcar_input1)
BW = 0.35/S.RiseTime % rule of thumb for the bandwidth of a signal

%%
figure
bode(qcar_model)