% Spring-Mass-Damper modeling

%%%%%%%%%%%%%%%%%%%%%%%%
%   Tommaso Menara     %
%      UCR-ME121       %
%%%%%%%%%%%%%%%%%%%%%%%%

clear all
close all
clc

m = 2; % mass [kg]
k = 0.5; % spring constant [N/m]

B = [0 1/m]'; % input matrix
C = [1 0]; % output matrix
D = [0]; % feedforward matrix


%% Change some parameters, e.g. damping

b = 0; % damping constant [Ns/m]
zeta = b/(2*sqrt(k*m)) % damping ratio
A = [0 1; -k/m -b/m];
sys0 = ss(A,B,C,D)
stepinfo(sys0)

b = 0.2;
zeta = b/(2*sqrt(k*m))
A = [0 1; -k/m -b/m];
sys1 = ss(A,B,C,D)
stepinfo(sys1)

b = 2;
zeta = b/(2*sqrt(k*m))
A = [0 1; -k/m -b/m];
sys2 = ss(A,B,C,D)
stepinfo(sys2)

b = 4;
zeta = b/(2*sqrt(k*m))
A = [0 1; -k/m -b/m];
sys3 = ss(A,B,C,D)
stepinfo(sys3)

figure(3)
step(sys0, 'g', sys1,'b--', sys2,'r:', sys3, 'k-.')
legend('\zeta = 0', '\zeta = 0.1','\zeta = 1', '\zeta=2')
xlim([0 60])

%% Bode diagrams

figure(4)
s = tf('s');
sys0 = 1/(m*s^2+0*s+k)
sys1 = 1/(m*s^2+0.2*s+k)
sys2 = 1/(m*s^2+2*s+k)
sys3 = 1/(m*s^2+4*s+k)
bode(sys0, 'g', sys1,'b--', sys2,'r:', sys3, 'k-.')
legend('\zeta = 0', '\zeta = 0.1','\zeta = 1', '\zeta=2')