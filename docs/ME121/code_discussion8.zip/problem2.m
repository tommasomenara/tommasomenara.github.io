% code to solve problem 2 Homework week 8

clear all
close all
clc

A = [0 1; -6 -8]

B = [0;1]

[V, E] = eig(A) % eigenvectors and eigenvalues

%% let x = Vz and transform the system to coordinates z

A_tilde = inv(V)*A*V

B_tilde = inv(V)*B

%% controllability matrix

C = ctrb(A,B)

rank(C)

%% characterize the system with input 0

sys = ss(A,B,[1 0],[]);
t = 0:0.1:10; % time vector
u = zeros(length(t),1);
lsim(sys, u, t)
step(sys)
transfer_func = tf(sys)

%% assign eigenvalues to -4 and -5

p = [-4, -5];
K = place(A,B,p)
A_closed_loop = A-B*K;
eig(A_closed_loop)

%% adjust input to obtain unitary steady state response

sys_cl = ss(A_closed_loop,B,[1 0],[]);
Kdc = dcgain(sys_cl)
Kr = 1/Kdc
step(sys_cl)

% create scaled input closed loop system
sys_scaled_input = ss(A_closed_loop, B*Kr, [1 0], []);
step(sys_scaled_input)


